<?php
/**
 * Department
 *
 */
Route::group(['namespace' => 'Api\Product'], function () {
	// Route::post('/cart/add','CartController@add');
	// Route::get('/cart/get','CartController@get');

    

});
