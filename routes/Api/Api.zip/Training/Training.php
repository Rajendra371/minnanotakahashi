<?php

/**
 * Training
 *
 */
Route::group(['namespace' => 'Api\Training'], function () {
    Route::post('/training/store', 'TrainingController@store');
    Route::post('/training/edit', 'TrainingController@edit');
    Route::post('/training/view', 'TrainingController@view');
    Route::post('/training/delete', 'TrainingController@delete');
    Route::get('/training/datatable_list', 'TrainingController@datatable_list');
    Route::get('/training/datatable_employee_training', 'TrainingController@datatable_employee_training');
});